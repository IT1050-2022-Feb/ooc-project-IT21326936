#pragma once
#define SIZE 2
#include <iostream>
using namespace std;
#include"Orders.h"


class Products
{
private:
	int productId;
	char prodName[30];
	char manufComp[40];
	char manufDate[10];
	char expDate[10];
	int price;
	Orders *ords[SIZE]
public:
	Products();
	Products(int pdtId, char pdtName[], char manfCom[], char manfDte[], char expDte[], int pric);
	void displayProductDetails(char pdtName[], char manfCom[], char manfDte[], char expDte[], int pric);
	void updateProductDetails();
	void checkAvailability();
	~Products();
	
};