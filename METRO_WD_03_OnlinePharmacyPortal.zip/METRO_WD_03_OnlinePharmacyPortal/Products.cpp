#include "Products.h"
#include<cstring>
#include "Orders.h"


Products::Products()
{
	pdtId = 0;
	pric = 0;

	for (int i = 0; i < size2; i++) 
	{
		ords[i] = new ords(0, 0);
	}
}

Products::Products(int pdtId, char pdtName[], char manfCom[], char manfDte[], char expDte[], int pric)
{
	price = pric;
	productId = pdtId;
	strcpy(prodName, pdtName);
	strcpy(manufComp, manfCom);
	strcpy(manufDate, manfDte);
	strcpy(expDate, expDte);
}

void Products::displayProductDetails(char pdtName[], char manfCom[], char manfDte[], char expDte[], int pric)
{
	cout << "Product Name: " << pdtName << endl;
	cout << "Manufacturer Company: " << manfCom << endl;
	cout << "Manufacturer Date: " << manfDte << endl;
	cout << "Exp Date: " << expDte << endl;
	cout << "Price: " << pric << endl;
}


void Products::updateProductDetails() 
{
}

void Products::checkAvailability() 
{
}

Products::~Products()
{
}