#include <iostream>
using namespace std;

#include "Payments.h"
#include <cstring>

Payments::Payments(int pId)
{
	pId = 0;
}

Payments::Payments(int pId, char payTyp[], double payAmt, char Method[])
{
	pId = payId;
	payAmt = payAmount;
	strcpy(payTyp, payType);
	strcpy(Method, method);
}

void Payments::paymentMethod(char Method[])
{
	cout << "Enter Payment Method (Card/Online Payment/Cash-on-Delivery) : " << endl;
	cin >> Method;

}

void Payments::confirmPayment()
{
}

double Payments::getpayId()
{
	return pId;
}

void Payments::displayPaymentDetails(char payTyp[], double payAmt, char Method[])
{
}

Payments::~Payments()
{
}