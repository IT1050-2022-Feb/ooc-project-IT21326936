#pragma once
#include <iostream>
using namespace std;

class Payments
{
private:
	int payId;
	char payType[20];
	double payAmount;
	char method[20]; 
public:
	Payments(int pId);
	Payments(int pId, char payTyp[], double payAmt, char Method[]);
	void paymentMethod(char Method[]);
	void confirmPayment();
	double getpayId();
	void displayPaymentDetails(char payTyp[], double payAmt, char Method[]);
	~Payments();
};

